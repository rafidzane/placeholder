import classnames from "classnames";
import formatRelative from "date-fns/formatRelative";
import React from "react";
import { useChannelStore } from "../stores/channels";
import { useMessageStore } from "../stores/messages";
//import { userReactionsStore } from "../stores/reactions";
import { useUserStore } from "../stores/users";
import MessageEditor from "./MessageEditor";
import styles from "./MessageViewer.module.css";
import { editReactions } from "../actions"; 


const Message = ({ content, createdAt, id, userId, channelId, userMap = {} }) => {
  const [isEditing, setIsEditing] = React.useState(false);
  const [reactions, setReactions] = React.useState({});
  const user = useUserStore((state) =>
    state.users.find((user) => user.id === userId)
  );
  const activeUserId = useUserStore((state) => state.activeUserId);
  const dateInstance = React.useMemo(() => new Date(createdAt), [createdAt]);
  const aggregateReactions = (userMap) => {
    let totalLikes = 0;   
    let totalLoves = 0; 
    let totalLaughs = 0;
    Object.values(userMap).forEach((user) => {
      totalLikes += user.likes;
      totalLoves += user.loves;
      totalLaughs += user.laughs;
    });
    return { totalLikes, totalLoves, totalLaughs }
  }
  
  React.useEffect(() => {
    const { totalLikes, totalLoves, totalLaughs} = aggregateReactions(userMap);
    setReactions({ totalLikes, totalLoves, totalLaughs });
  }, [userMap]);

  const toggleReaction = async (reaction) => {
    console.log(activeUserId);
    let userInfo = userMap[activeUserId]
    if(userInfo === undefined){
      userInfo = { likes:0, laughs:0, loves:0}
    } 
    if(reaction === 'likes') {
      if (userInfo.likes === 1) {
        userInfo.likes = 0;
      } else {
        userInfo.likes = 1;
      }
    } else if (reaction === 'loves') {
      if (userInfo.loves === 1) {
        userInfo.loves = 0;
      } else {
        userInfo.loves = 1;
      }
    } else if (reaction === 'laughs') {
      if (userInfo.laughs === 1) {
        userInfo.laughs = 0;
      } else {
        userInfo.laughs = 1;
      }
    }
    let responseMsg = await editReactions({  messageId: id, channelId, userId: activeUserId, content: userInfo })
    userMap = responseMsg.userMap
    //console.log("EMITTING GET ALL ",responseMsg)
    const reactions = aggregateReactions(userMap)
    setReactions({ ...reactions })

    }

  return (
    <div className={styles.message}>
      <div className={styles.metadata}>
        {user == null ? null : (
          <span className={styles.username}>{user.username}</span>
        )}
        <span className={styles.timestamp}>
          {formatRelative(dateInstance, new Date())}
        </span>
      </div>
      {isEditing ? (
        <MessageEditor
          channelId={channelId}
          id={id}
          content={content}
          onClose={() => setIsEditing(false)}
        />
      ) : (
        content
      )}
      {userId === activeUserId && !isEditing ? (
        <button
          onClick={() => setIsEditing(true)}
          className={styles.editButton}
        >
          Edit
        </button>
      ) : null}
      
      <br></br>
      <span className={styles.username} onClick={() => toggleReaction('likes')}>like {reactions.totalLikes} </span>
      <span className={styles.username} onClick={() => toggleReaction('laughs')}>laugh {reactions.totalLaughs}</span>
      <span className={styles.username} onClick={() => toggleReaction('loves')} >love {reactions.totalLoves}</span>
    </div>
  );
};

const MessageViewer = () => {
  const allMessages = useMessageStore((state) => state.messages); 
  const activeChannelId = useChannelStore((state) => state.activeChannelId);
  const messagesForActiveChannel = React.useMemo(
    () =>
      allMessages.filter((message) => message.channelId === activeChannelId),
    [activeChannelId, allMessages]
  );
  const isEmpty = messagesForActiveChannel.length === 0;

  return (
    <div
      className={classnames(styles.wrapper, { [styles.wrapperEmpty]: isEmpty })}
    >
      {isEmpty ? (
        <div className={styles.empty}>
          No messages{" "}
          <span aria-label="Sad face" role="img">
            😢
          </span>
        </div>
      ) : (
        messagesForActiveChannel.map((message) => (
          <Message
            channelId={activeChannelId}
            key={message.id}
            id={message.id}
            content={message.content}
            createdAt={message.createdAt}
            userId={message.userId}
            userMap={message.userMap}
          />
        ))
      )}
    </div>
  );
};

export default MessageViewer;
